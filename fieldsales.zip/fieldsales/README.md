# Field Sales Visit Management – MVP

backend/  FastAPI + SQLite server, plus manager web dashboard at /admin
app/      Flutter app (Android + iOS)

## 1. Run the backend
cd backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
Manager dashboard: http://localhost:8000/admin

Demo logins:  admin/admin123   manager/manager123   sales1/sales123
(Change these before real use. Add salespeople with POST /users as admin — see http://localhost:8000/docs)

## 2. Build the app / APK
Install Flutter (https://docs.flutter.dev/get-started/install), then:
cd app
./setup.sh                      # creates android/ios folders, adds permissions
flutter run                     # test on a connected phone/emulator
flutter build apk --release     # APK: build/app/outputs/flutter-apk/app-release.apk

On the login screen set "Server URL":
- Android emulator:  http://10.0.2.2:8000
- Real phone on same Wi-Fi:  http://<your-PC-LAN-IP>:8000
- Cloud:  https://your-server  (deploy backend/ to any VPS, Render, Railway, etc.)

## MVP scope
Done: roles, login, customer DB (name/phone/shop/address/GPS/photo), plan + check-in/check-out with GPS,
notes, customer response, follow-up date, route map, daily/weekly/monthly reports, manager dashboard + CSV export.
Not yet: offline mode/sync, push-notification reminders, periodic tracking, HTTPS/hardening, iOS signing.
Location is captured only at check-in/check-out, and the user taps the buttons (no hidden tracking).
