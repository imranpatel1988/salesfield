import os, sqlite3, secrets, hashlib, shutil, csv, io, hmac
import datetime as dt
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, Header, UploadFile, File
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

DB = os.environ.get("DB_PATH", "fieldsales.db")
os.makedirs("uploads", exist_ok=True)
app = FastAPI(title="Field Sales MVP")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def rows(sql, args=()):
    c = db(); r = [dict(x) for x in c.execute(sql, args).fetchall()]; c.close(); return r

def run(sql, args=()):
    c = db(); cur = c.execute(sql, args); c.commit(); i = cur.lastrowid; c.close(); return i

def hp(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100000).hex()

def check(pw, stored):
    return hmac.compare_digest(hp(pw, stored.split("$")[0]), stored)

def now(): return dt.datetime.now().isoformat(timespec="seconds")
def today(): return dt.date.today().isoformat()

def init():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, username TEXT UNIQUE, pw TEXT, role TEXT);
    CREATE TABLE IF NOT EXISTS tokens(token TEXT PRIMARY KEY, user_id INTEGER);
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY, owner_id INTEGER, shop_name TEXT, name TEXT, phone TEXT, address TEXT, lat REAL, lng REAL, photo TEXT);
    CREATE TABLE IF NOT EXISTS visits(id INTEGER PRIMARY KEY, user_id INTEGER, customer_id INTEGER, planned_date TEXT, status TEXT DEFAULT 'planned',
      in_time TEXT, in_lat REAL, in_lng REAL, out_time TEXT, out_lat REAL, out_lng REAL, notes TEXT, response TEXT, follow_up_date TEXT);
    """)
    if not c.execute("SELECT 1 FROM users").fetchone():
        for n, u, p, r in [("Admin", "admin", "admin123", "admin"), ("Sales Manager", "manager", "manager123", "manager"),
                           ("Salesperson One", "sales1", "sales123", "salesperson")]:
            c.execute("INSERT INTO users(name,username,pw,role) VALUES(?,?,?,?)", (n, u, hp(p), r))
    c.commit(); c.close()
init()

def me(authorization: str = Header(None)):
    if not authorization: raise HTTPException(401, "Not logged in")
    t = authorization.replace("Bearer ", "")
    r = rows("SELECT u.* FROM tokens t JOIN users u ON u.id=t.user_id WHERE t.token=?", (t,))
    if not r: raise HTTPException(401, "Session expired, log in again")
    return r[0]

def manager_only(u=Depends(me)):
    if u["role"] == "salesperson": raise HTTPException(403, "Managers only")
    return u

def scope(u, user_id):
    return u["id"] if u["role"] == "salesperson" else user_id

class Login(BaseModel): username: str; password: str
@app.post("/login")
def login(b: Login):
    r = rows("SELECT * FROM users WHERE username=?", (b.username.strip(),))
    if not r or not check(b.password, r[0]["pw"]): raise HTTPException(400, "Wrong username or password")
    t = secrets.token_hex(24); run("INSERT INTO tokens VALUES(?,?)", (t, r[0]["id"]))
    return {"token": t, "user": {"id": r[0]["id"], "name": r[0]["name"], "role": r[0]["role"]}}

class NewUser(BaseModel): name: str; username: str; password: str; role: str = "salesperson"
@app.post("/users")
def add_user(b: NewUser, u=Depends(me)):
    if u["role"] != "admin": raise HTTPException(403, "Admin only")
    if b.role not in ("admin", "manager", "salesperson"): raise HTTPException(400, "Bad role")
    try: return {"id": run("INSERT INTO users(name,username,pw,role) VALUES(?,?,?,?)", (b.name, b.username, hp(b.password), b.role))}
    except sqlite3.IntegrityError: raise HTTPException(400, "Username already exists")

@app.get("/users")
def users(u=Depends(manager_only)):
    return rows("SELECT id,name,username,role FROM users ORDER BY id")

class Cust(BaseModel):
    shop_name: str; name: str; phone: str = ""; address: str = ""
    lat: Optional[float] = None; lng: Optional[float] = None

@app.get("/customers")
def customers(u=Depends(me)):
    if u["role"] == "salesperson":
        return rows("SELECT * FROM customers WHERE owner_id=? ORDER BY shop_name", (u["id"],))
    return rows("SELECT * FROM customers ORDER BY shop_name")

@app.post("/customers")
def add_customer(b: Cust, u=Depends(me)):
    return {"id": run("INSERT INTO customers(owner_id,shop_name,name,phone,address,lat,lng) VALUES(?,?,?,?,?,?,?)",
                      (u["id"], b.shop_name, b.name, b.phone, b.address, b.lat, b.lng))}

@app.post("/customers/{cid}/photo")
def photo(cid: int, file: UploadFile = File(...), u=Depends(me)):
    fn = f"{cid}_{secrets.token_hex(4)}.jpg"
    with open(f"uploads/{fn}", "wb") as f: shutil.copyfileobj(file.file, f)
    run("UPDATE customers SET photo=? WHERE id=?", (f"/uploads/{fn}", cid))
    return {"photo": f"/uploads/{fn}"}

VQ = ("SELECT v.*, c.shop_name, c.name AS customer_name, c.phone, c.lat AS shop_lat, c.lng AS shop_lng, u.name AS salesperson "
      "FROM visits v JOIN customers c ON c.id=v.customer_id JOIN users u ON u.id=v.user_id")

class NewVisit(BaseModel): customer_id: int; planned_date: Optional[str] = None
@app.post("/visits")
def new_visit(b: NewVisit, u=Depends(me)):
    d = b.planned_date or today()
    ex = rows("SELECT id FROM visits WHERE user_id=? AND customer_id=? AND planned_date=? AND status!='completed'", (u["id"], b.customer_id, d))
    if ex: return {"id": ex[0]["id"]}
    return {"id": run("INSERT INTO visits(user_id,customer_id,planned_date) VALUES(?,?,?)", (u["id"], b.customer_id, d))}

@app.get("/visits")
def visits(day: Optional[str] = None, user_id: Optional[int] = None, u=Depends(me)):
    q = VQ + " WHERE v.planned_date=?"; a = [day or today()]
    uid = scope(u, user_id)
    if uid: q += " AND v.user_id=?"; a.append(uid)
    return rows(q + " ORDER BY v.id", a)

@app.get("/visits/{vid}")
def visit(vid: int, u=Depends(me)):
    r = rows(VQ + " WHERE v.id=?", (vid,))
    if not r: raise HTTPException(404, "Visit not found")
    return r[0]

class Loc(BaseModel): lat: float; lng: float
@app.post("/visits/{vid}/checkin")
def checkin(vid: int, b: Loc, u=Depends(me)):
    run("UPDATE visits SET status='checked_in', in_time=?, in_lat=?, in_lng=? WHERE id=? AND user_id=?", (now(), b.lat, b.lng, vid, u["id"]))
    return {"ok": True}

class Out(BaseModel):
    lat: float; lng: float; notes: str = ""; response: str = "interested"; follow_up_date: Optional[str] = None
@app.post("/visits/{vid}/checkout")
def checkout(vid: int, b: Out, u=Depends(me)):
    run("UPDATE visits SET status='completed', out_time=?, out_lat=?, out_lng=?, notes=?, response=?, follow_up_date=? WHERE id=? AND user_id=?",
        (now(), b.lat, b.lng, b.notes, b.response, b.follow_up_date, vid, u["id"]))
    return {"ok": True}

@app.get("/followups")
def followups(user_id: Optional[int] = None, u=Depends(me)):
    q = VQ + " WHERE v.follow_up_date IS NOT NULL AND v.follow_up_date!='' AND v.follow_up_date>=?"; a = [today()]
    uid = scope(u, user_id)
    if uid: q += " AND v.user_id=?"; a.append(uid)
    return rows(q + " ORDER BY v.follow_up_date", a)

@app.get("/route")
def route(day: Optional[str] = None, user_id: Optional[int] = None, u=Depends(me)):
    q = VQ + " WHERE v.planned_date=? AND v.in_lat IS NOT NULL"; a = [day or today()]
    uid = scope(u, user_id)
    if uid: q += " AND v.user_id=?"; a.append(uid)
    return rows(q + " ORDER BY v.in_time", a)

def report_data(period):
    t = dt.date.today()
    start = {"day": t, "week": t - dt.timedelta(days=6), "month": t - dt.timedelta(days=29)}.get(period, t)
    return start.isoformat(), t.isoformat()

@app.get("/reports")
def reports(period: str = "day", u=Depends(me)):
    s, e = report_data(period)
    us = rows("SELECT id,name FROM users WHERE role='salesperson'")
    if u["role"] == "salesperson": us = [{"id": u["id"], "name": u["name"]}]
    out = []
    for x in us:
        vs = rows("SELECT * FROM visits WHERE user_id=? AND planned_date>=? AND planned_date<=?", (x["id"], s, e))
        done = [v for v in vs if v["status"] == "completed"]
        mins = []
        for v in done:
            try: mins.append((dt.datetime.fromisoformat(v["out_time"]) - dt.datetime.fromisoformat(v["in_time"])).seconds / 60)
            except Exception: pass
        cnt = lambda r: len([v for v in done if v["response"] == r])
        out.append({"user_id": x["id"], "name": x["name"], "planned": len(vs), "completed": len(done),
                    "missed": len([v for v in vs if v["status"] != "completed" and v["planned_date"] < today()]),
                    "interested": cnt("interested"), "follow_up": cnt("follow_up"), "call_later": cnt("call_later"),
                    "not_interested": cnt("not_interested"), "avg_minutes": round(sum(mins) / len(mins), 1) if mins else 0})
    return out

@app.get("/reports/export.csv")
def export(period: str = "month", u=Depends(manager_only)):
    s, e = report_data(period)
    d = rows(VQ + " WHERE v.planned_date>=? AND v.planned_date<=? ORDER BY v.planned_date, v.id", (s, e))
    f = io.StringIO(); w = csv.writer(f)
    w.writerow(["date", "salesperson", "shop", "customer", "phone", "status", "check_in", "check_out", "response", "follow_up", "notes", "in_lat", "in_lng"])
    for v in d:
        w.writerow([v["planned_date"], v["salesperson"], v["shop_name"], v["customer_name"], v["phone"], v["status"], v["in_time"], v["out_time"],
                    v["response"], v["follow_up_date"], v["notes"], v["in_lat"], v["in_lng"]])
    return Response(f.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=visits.csv"})

@app.get("/admin", response_class=HTMLResponse)
def admin():
    return open(os.path.join(os.path.dirname(__file__), "admin.html"), encoding="utf-8").read()
