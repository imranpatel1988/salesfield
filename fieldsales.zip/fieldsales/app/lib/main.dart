import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'api.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.init();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'Field Sales',
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        home: Api.token == null ? const LoginPage() : const Home(),
      );
}

void toast(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
String err(Object e) => e.toString().replaceFirst('Exception: ', '');

Future<Position> getPos() async {
  if (!await Geolocator.isLocationServiceEnabled()) throw Exception('Turn on phone location (GPS)');
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied || p == LocationPermission.deniedForever) throw Exception('Location permission denied');
  return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
}

/// Loads a GET path and rebuilds with the data. Pull down to refresh.
class Fut extends StatefulWidget {
  final String path;
  final Widget Function(BuildContext, dynamic, VoidCallback) b;
  const Fut(this.path, this.b, {super.key});
  @override
  State<Fut> createState() => _FutState();
}

class _FutState extends State<Fut> {
  late Future f = Api.get(widget.path);
  void reload() => setState(() => f = Api.get(widget.path));
  @override
  void didUpdateWidget(Fut o) {
    super.didUpdateWidget(o);
    if (o.path != widget.path) f = Api.get(widget.path);
  }

  @override
  Widget build(BuildContext c) => FutureBuilder(
        future: f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (s.hasError) {
            return Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(padding: const EdgeInsets.all(16), child: Text(err(s.error!), textAlign: TextAlign.center)),
              FilledButton(onPressed: reload, child: const Text('Retry'))
            ]));
          }
          return RefreshIndicator(onRefresh: () async => reload(), child: widget.b(c, s.data, reload));
        },
      );
}

Widget emptyList(String m) => ListView(physics: const AlwaysScrollableScrollPhysics(), children: [Padding(padding: const EdgeInsets.all(32), child: Center(child: Text(m)))]);

// ---------------- Login ----------------
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginState();
}

class _LoginState extends State<LoginPage> {
  final u = TextEditingController(text: 'sales1'), p = TextEditingController(), s = TextEditingController(text: Api.base);
  bool busy = false;
  Future<void> go() async {
    setState(() => busy = true);
    try {
      final base = s.text.trim().replaceAll(RegExp(r'/+$'), '');
      Api.base = base;
      final r = await Api.post('/login', {'username': u.text, 'password': p.text});
      await Api.save(base, r['token'], r['user']);
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home()));
    } catch (e) {
      if (mounted) toast(context, err(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(
            child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 40),
          const Icon(Icons.storefront, size: 64),
          const Center(child: Text('Field Sales', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold))),
          const SizedBox(height: 24),
          TextField(controller: u, decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: p, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: s, decoration: const InputDecoration(labelText: 'Server URL', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          FilledButton(onPressed: busy ? null : go, child: Text(busy ? 'Please wait...' : 'Login')),
        ])),
      );
}

// ---------------- Home ----------------
class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = 0;
  @override
  Widget build(BuildContext c) {
    final pages = const [TodayPage(), CustomersPage(), FollowupsPage(), ReportsPage()];
    return Scaffold(
      appBar: AppBar(title: Text('${Api.user['name']} (${Api.user['role']})', style: const TextStyle(fontSize: 16)), actions: [
        IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await Api.save(Api.base, null, {});
              if (c.mounted) Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => const LoginPage()));
            })
      ]),
      body: pages[i],
      bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (x) => setState(() => i = x), destinations: const [
        NavigationDestination(icon: Icon(Icons.today), label: 'Today'),
        NavigationDestination(icon: Icon(Icons.store), label: 'Customers'),
        NavigationDestination(icon: Icon(Icons.event_repeat), label: 'Follow-ups'),
        NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Reports'),
      ]),
    );
  }
}

// ---------------- Today ----------------
Color statusColor(String s) => s == 'completed' ? Colors.green : s == 'checked_in' ? Colors.orange : Colors.grey;

class TodayPage extends StatefulWidget {
  const TodayPage({super.key});
  @override
  State<TodayPage> createState() => _TodayState();
}

class _TodayState extends State<TodayPage> {
  DateTime day = DateTime.now();
  String get ds => day.toIso8601String().substring(0, 10);
  @override
  Widget build(BuildContext c) => Column(children: [
        ListTile(
          title: Text('Visits: $ds'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(
                icon: const Icon(Icons.calendar_month),
                onPressed: () async {
                  final d = await showDatePicker(context: c, initialDate: day, firstDate: DateTime(2024), lastDate: DateTime(2100));
                  if (d != null) setState(() => day = d);
                }),
            IconButton(icon: const Icon(Icons.map), onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => RoutePage(ds)))),
          ]),
        ),
        Expanded(
            child: Fut('/visits?day=$ds', (c, d, reload) {
          final l = d as List;
          if (l.isEmpty) return emptyList('No visits planned. Go to Customers and tap a shop to plan a visit.');
          return ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: l.length,
              itemBuilder: (c, i) {
                final v = l[i];
                return ListTile(
                  leading: Icon(Icons.circle, color: statusColor(v['status'])),
                  title: Text(v['shop_name']),
                  subtitle: Text('${v['customer_name']} • ${v['salesperson']}\n${v['status']}${v['response'] != null ? ' • ${v['response']}' : ''}'),
                  isThreeLine: true,
                  onTap: () async {
                    await Navigator.push(c, MaterialPageRoute(builder: (_) => VisitPage(v['id'])));
                    reload();
                  },
                );
              });
        })),
      ]);
}

// ---------------- Customers ----------------
class CustomersPage extends StatelessWidget {
  const CustomersPage({super.key});
  @override
  Widget build(BuildContext c) => Fut('/customers', (c, d, reload) {
        final l = d as List;
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
              icon: const Icon(Icons.add),
              label: const Text('Add customer'),
              onPressed: () async {
                await Navigator.push(c, MaterialPageRoute(builder: (_) => const AddCustomerPage()));
                reload();
              }),
          body: l.isEmpty
              ? emptyList('No customers yet. Tap "Add customer".')
              : ListView.builder(
                  physics: const AlwaysScrollableScrollPhysics(),
                  itemCount: l.length,
                  itemBuilder: (c, i) {
                    final x = l[i];
                    return ListTile(
                      leading: x['photo'] != null
                          ? CircleAvatar(backgroundImage: NetworkImage('${Api.base}${x['photo']}'))
                          : const CircleAvatar(child: Icon(Icons.store)),
                      title: Text(x['shop_name']),
                      subtitle: Text('${x['name']} • ${x['phone']}\n${x['address']}'),
                      isThreeLine: true,
                      trailing: const Icon(Icons.play_circle_outline),
                      onTap: () async {
                        try {
                          final r = await Api.post('/visits', {'customer_id': x['id']});
                          if (c.mounted) await Navigator.push(c, MaterialPageRoute(builder: (_) => VisitPage(r['id'])));
                        } catch (e) {
                          if (c.mounted) toast(c, err(e));
                        }
                      },
                    );
                  }),
        );
      });
}

class AddCustomerPage extends StatefulWidget {
  const AddCustomerPage({super.key});
  @override
  State<AddCustomerPage> createState() => _AddState();
}

class _AddState extends State<AddCustomerPage> {
  final shop = TextEditingController(), name = TextEditingController(), phone = TextEditingController(), addr = TextEditingController();
  double? lat, lng;
  File? img;
  bool busy = false;

  Future<void> gps() async {
    try {
      final p = await getPos();
      setState(() { lat = p.latitude; lng = p.longitude; });
    } catch (e) { if (mounted) toast(context, err(e)); }
  }

  Future<void> snap() async {
    final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 70, maxWidth: 1280);
    if (x != null) setState(() => img = File(x.path));
  }

  Future<void> save() async {
    if (shop.text.trim().isEmpty || name.text.trim().isEmpty) { toast(context, 'Shop name and customer name are required'); return; }
    setState(() => busy = true);
    try {
      final r = await Api.post('/customers', {'shop_name': shop.text.trim(), 'name': name.text.trim(), 'phone': phone.text.trim(), 'address': addr.text.trim(), 'lat': lat, 'lng': lng});
      if (img != null) await Api.upload('/customers/${r['id']}/photo', img!);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) toast(context, err(e));
    }
    if (mounted) setState(() => busy = false);
  }

  Widget f(String l, TextEditingController c, [TextInputType? t]) =>
      Padding(padding: const EdgeInsets.only(bottom: 12), child: TextField(controller: c, keyboardType: t, decoration: InputDecoration(labelText: l, border: const OutlineInputBorder())));

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Add customer')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          f('Shop name *', shop), f('Customer name *', name), f('Phone', phone, TextInputType.phone), f('Address', addr),
          OutlinedButton.icon(onPressed: gps, icon: const Icon(Icons.my_location), label: Text(lat == null ? 'Capture shop GPS' : 'GPS: ${lat!.toStringAsFixed(5)}, ${lng!.toStringAsFixed(5)}')),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: snap, icon: const Icon(Icons.camera_alt), label: Text(img == null ? 'Take shop photo' : 'Photo captured (tap to retake)')),
          if (img != null) Padding(padding: const EdgeInsets.only(top: 8), child: Image.file(img!, height: 180)),
          const SizedBox(height: 16),
          FilledButton(onPressed: busy ? null : save, child: Text(busy ? 'Saving...' : 'Save')),
        ]),
      );
}

// ---------------- Visit ----------------
class VisitPage extends StatefulWidget {
  final int id;
  const VisitPage(this.id, {super.key});
  @override
  State<VisitPage> createState() => _VisitState();
}

class _VisitState extends State<VisitPage> {
  Map? v;
  String? error;
  bool busy = false;
  final notes = TextEditingController();
  String resp = 'interested';
  String? follow;
  static const responses = {'interested': 'Interested', 'follow_up': 'Follow-up required', 'call_later': 'Call later', 'not_interested': 'Not interested'};

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final r = await Api.get('/visits/${widget.id}');
      if (mounted) setState(() { v = r; error = null; });
    } catch (e) { if (mounted) setState(() => error = err(e)); }
  }

  Future<void> act(Future<void> Function() fn) async {
    setState(() => busy = true);
    try { await fn(); await load(); } catch (e) { if (mounted) toast(context, err(e)); }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext c) {
    if (v == null) return Scaffold(appBar: AppBar(), body: Center(child: error != null ? Text(error!) : const CircularProgressIndicator()));
    final x = v!;
    final st = x['status'] as String;
    final mine = x['user_id'] == Api.user['id'];
    String dist = '';
    if (x['in_lat'] != null && x['shop_lat'] != null) {
      dist = '\nChecked in ${Geolocator.distanceBetween(x['in_lat'], x['in_lng'], x['shop_lat'], x['shop_lng']).round()} m from saved shop location';
    }
    return Scaffold(
      appBar: AppBar(title: Text(x['shop_name'])),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(title: Text(x['customer_name']), subtitle: Text('${x['phone']}\nStatus: $st${x['in_time'] != null ? '\nIn: ${x['in_time']}' : ''}${x['out_time'] != null ? '\nOut: ${x['out_time']}' : ''}$dist')),
        if (st == 'planned' && mine)
          FilledButton.icon(
              icon: const Icon(Icons.login),
              label: Text(busy ? 'Getting GPS...' : 'Check in (records GPS + time)'),
              onPressed: busy ? null : () => act(() async { final p = await getPos(); await Api.post('/visits/${widget.id}/checkin', {'lat': p.latitude, 'lng': p.longitude}); })),
        if (st == 'checked_in' && mine) ...[
          TextField(controller: notes, maxLines: 4, decoration: const InputDecoration(labelText: 'Discussion notes', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
              value: resp,
              decoration: const InputDecoration(labelText: 'Customer response', border: OutlineInputBorder()),
              items: responses.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
              onChanged: (z) => setState(() => resp = z!)),
          const SizedBox(height: 12),
          OutlinedButton.icon(
              icon: const Icon(Icons.event),
              label: Text(follow == null ? 'Set next call/visit date' : 'Follow-up: $follow'),
              onPressed: () async {
                final d = await showDatePicker(context: c, initialDate: DateTime.now().add(const Duration(days: 1)), firstDate: DateTime.now(), lastDate: DateTime(2100));
                if (d != null) setState(() => follow = d.toIso8601String().substring(0, 10));
              }),
          const SizedBox(height: 12),
          FilledButton.icon(
              icon: const Icon(Icons.logout),
              label: Text(busy ? 'Getting GPS...' : 'Check out'),
              onPressed: busy ? null : () => act(() async { final p = await getPos(); await Api.post('/visits/${widget.id}/checkout', {'lat': p.latitude, 'lng': p.longitude, 'notes': notes.text, 'response': resp, 'follow_up_date': follow}); })),
        ],
        if (st == 'completed') ...[
          const Divider(),
          ListTile(title: const Text('Response'), subtitle: Text(responses[x['response']] ?? '${x['response']}')),
          ListTile(title: const Text('Notes'), subtitle: Text('${x['notes'] ?? ''}')),
          if (x['follow_up_date'] != null) ListTile(title: const Text('Next follow-up'), subtitle: Text('${x['follow_up_date']}')),
        ],
      ]),
    );
  }
}

// ---------------- Follow-ups ----------------
class FollowupsPage extends StatelessWidget {
  const FollowupsPage({super.key});
  @override
  Widget build(BuildContext c) => Fut('/followups', (c, d, reload) {
        final l = d as List;
        if (l.isEmpty) return emptyList('No upcoming follow-ups.');
        return ListView.builder(
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: l.length,
            itemBuilder: (c, i) => ListTile(
                leading: const Icon(Icons.event),
                title: Text('${l[i]['shop_name']} — ${l[i]['follow_up_date']}'),
                subtitle: Text('${l[i]['customer_name']} • ${l[i]['phone']}\n${l[i]['notes'] ?? ''}'),
                isThreeLine: true));
      });
}

// ---------------- Reports ----------------
class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _ReportsState();
}

class _ReportsState extends State<ReportsPage> {
  String period = 'day';
  @override
  Widget build(BuildContext c) => Column(children: [
        Padding(
            padding: const EdgeInsets.all(8),
            child: SegmentedButton<String>(
                segments: const [ButtonSegment(value: 'day', label: Text('Daily')), ButtonSegment(value: 'week', label: Text('Weekly')), ButtonSegment(value: 'month', label: Text('Monthly'))],
                selected: {period},
                onSelectionChanged: (s) => setState(() => period = s.first))),
        Expanded(
            child: Fut('/reports?period=$period', (c, d, reload) {
          final l = d as List;
          return ListView(physics: const AlwaysScrollableScrollPhysics(), children: [
            for (final r in l)
              Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(r['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('Planned ${r['planned']} • Completed ${r['completed']} • Missed ${r['missed']}\n'
                        'Interested ${r['interested']} • Follow-up ${r['follow_up']} • Call later ${r['call_later']} • Not interested ${r['not_interested']}\n'
                        'Avg visit time: ${r['avg_minutes']} min\nTap to see today\'s route'),
                    isThreeLine: true,
                    onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => RoutePage(DateTime.now().toIso8601String().substring(0, 10), userId: r['user_id']))),
                  )),
          ]);
        })),
      ]);
}

// ---------------- Route map ----------------
class RoutePage extends StatelessWidget {
  final String day;
  final int? userId;
  const RoutePage(this.day, {this.userId, super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text('Route $day')),
        body: Fut('/route?day=$day${userId != null ? '&user_id=$userId' : ''}', (c, d, reload) {
          final l = d as List;
          final pts = <LatLng>[];
          final marks = <Marker>[];
          for (var i = 0; i < l.length; i++) {
            final v = l[i];
            final a = LatLng(v['in_lat'], v['in_lng']);
            pts.add(a);
            marks.add(Marker(point: a, width: 44, height: 44, child: Tooltip(message: '${i + 1}. ${v['shop_name']}', child: const Icon(Icons.location_on, color: Colors.red, size: 40))));
            if (v['out_lat'] != null) pts.add(LatLng(v['out_lat'], v['out_lng']));
          }
          if (pts.isEmpty) return emptyList('No check-ins recorded for this day.');
          return Column(children: [
            Expanded(
                child: FlutterMap(
              options: MapOptions(initialCenter: pts.first, initialZoom: 14),
              children: [
                TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.fieldsales'),
                PolylineLayer(polylines: [Polyline(points: pts, strokeWidth: 4, color: Colors.indigo)]),
                MarkerLayer(markers: marks),
              ],
            )),
            SizedBox(
                height: 120,
                child: ListView.builder(
                    itemCount: l.length,
                    itemBuilder: (c, i) => ListTile(dense: true, leading: CircleAvatar(radius: 12, child: Text('${i + 1}')), title: Text(l[i]['shop_name']), subtitle: Text('${l[i]['in_time']} → ${l[i]['out_time'] ?? 'in progress'}')))),
          ]);
        }),
      );
}
