import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  static String base = 'http://10.0.2.2:8000'; // Android emulator -> your PC. Change on the login screen.
  static String? token;
  static Map user = {};

  static Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    base = p.getString('base') ?? base;
    token = p.getString('token');
    final u = p.getString('user');
    if (u != null) user = jsonDecode(u);
  }

  static Future<void> save(String b, String? t, Map u) async {
    final p = await SharedPreferences.getInstance();
    base = b; token = t; user = u;
    await p.setString('base', b);
    if (t == null) { await p.remove('token'); await p.remove('user'); }
    else { await p.setString('token', t); await p.setString('user', jsonEncode(u)); }
  }

  static Map<String, String> get _h => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  static dynamic _d(http.Response r) {
    final body = r.body.isEmpty ? null : jsonDecode(r.body);
    if (r.statusCode >= 400) throw Exception(body is Map ? (body['detail'] ?? 'Error ${r.statusCode}') : 'Error ${r.statusCode}');
    return body;
  }

  static Future<dynamic> get(String path) async =>
      _d(await http.get(Uri.parse('$base$path'), headers: _h).timeout(const Duration(seconds: 20)));

  static Future<dynamic> post(String path, Map b) async =>
      _d(await http.post(Uri.parse('$base$path'), headers: _h, body: jsonEncode(b)).timeout(const Duration(seconds: 20)));

  static Future<void> upload(String path, File f) async {
    final req = http.MultipartRequest('POST', Uri.parse('$base$path'));
    req.headers['Authorization'] = 'Bearer $token';
    req.files.add(await http.MultipartFile.fromPath('file', f.path));
    final r = await req.send();
    if (r.statusCode >= 400) throw Exception('Photo upload failed');
  }
}
