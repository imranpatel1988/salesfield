#!/bin/bash
# Run inside the app/ folder. Requires Flutter SDK installed.
set -e
flutter create --org com.example --project-name fieldsales --platforms android,ios .
python3 setup_android.py
flutter pub get
echo "Done. Test: flutter run   |   APK: flutter build apk --release"
