"""Run once after `flutter create` (setup.sh does both): adds permissions to the generated Android/iOS projects."""
import pathlib
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
s = m.read_text()
if "ACCESS_FINE_LOCATION" not in s:
    perms = ('<uses-permission android:name="android.permission.INTERNET"/>\n'
             '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>\n'
             '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>\n'
             '<uses-permission android:name="android.permission.CAMERA"/>\n')
    s = s.replace("<application", perms + "<application", 1)
    s = s.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
    m.write_text(s)
p = pathlib.Path("ios/Runner/Info.plist")
if p.exists():
    t = p.read_text()
    if "NSLocationWhenInUseUsageDescription" not in t:
        keys = ("<key>NSLocationWhenInUseUsageDescription</key><string>Used to record your location at shop check-in and check-out.</string>\n"
                "<key>NSCameraUsageDescription</key><string>Used to take shop photos.</string>\n")
        i = t.rfind("</dict>")
        p.write_text(t[:i] + keys + t[i:])
print("Permissions added")
